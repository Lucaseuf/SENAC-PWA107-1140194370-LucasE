 /** - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * SENAC - TADS - Programacao Web *
 * ADO #02 Trabalhando As Rotas e LINKS *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Nome : Lucas Eufrasio Ferreira *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

import RouterApp from './Routes.js';

function App() {
  return (
    <div>
      <RouterApp/>
    </div>
  );
}

export default App;
