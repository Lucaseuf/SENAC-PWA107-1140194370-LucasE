import { Link } from "react-router-dom";
import './home.css'

function Home(){
 
    return(
        <div>
           
            <div>
                <h1 align = 'center'>Home Page</h1>
            </div>

            <br/>

                <div>
                    <p align = 'center'>
                            Seja bem vindo ao nosso sistema
                    </p>
                </div>
        </div>
    )
}
export default Home;