import {Link} from "react-router-dom"

function SobreNos(){
    return(
        <div>
            <div>
                <h1 align = 'center'>Sobre nós</h1>
                <br></br>
                <p align = 'center'>
                    O banco xuxu fundado em 31 de fevereiro de 1997 nasceu com a missão de entregar os 
                    melhores serviços e produtos
                </p>
                <p align = 'center'>
                 aos nossos clientes, sempre com o melhor custo-beneficio
                    para atender as necessidades de nossos clientes.
                </p>
                
                
                <br></br>
                <p align = 'center'>Autor: Lucas Eufrasio Ferreira - TADS B - Programação Web </p>
            </div>
        </div>

    )
}
export default SobreNos;